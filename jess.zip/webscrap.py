import pickle
from sklearn.feature_extraction.text import CountVectorizer
vec = pickle.load(open("vectorizer.pickle", 'rb'))
model = pickle.load(open('finalized_model.sav', 'rb'))
print(model.predict(vec.transform(['not a good day for nepal'])))
def predict(headings):
    predections = []
    for heading in headings:
        if model.predict(vec.transform([heading[1]]))[0] == 0:
            predections.append("Neutral")
        elif model.predict(vec.transform([heading[1]]))[0] == 1:
            predections.append("Positive")
        else:
            predections.append("Negative")
    return predections


with open('THT.pkl', 'rb') as f:
    THTLinks  = pickle.load(f)

with open('setopati.pkl', 'rb') as f:
    setopatiLinks  = pickle.load(f)



preds = predict(setopatiLinks)
print(preds)
links = ""
i = 0
for data in setopatiLinks:

    links = links + "<p><a href = \"" + data[0] + "\">"+str(data[1])+"</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp" + str(preds[i])
    i = i + 1

from flask import Flask

# app = Flask(__name__, instance_relative_config=True)
app = Flask(__name__)

@app.route("/tht")
def tht():
    return THTLinks


@app.route("/setopati")
def setopati():
    return links


@app.route("/")
def home():
    return "<a href=\"/tht\"> The Himalayan times </a><br><a href=\"/setopati\"> Setopati </a>"



if __name__ == '__main__':
   app.run()

# print(results)
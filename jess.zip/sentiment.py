import pandas as pd
from sklearn.model_selection import train_test_split
import joblib
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import pickle
sdata = pd.read_csv('test.csv', encoding= 'unicode_escape')
print()
print(sdata.head())


def preprocess_data(sdata):
    # Remove package name as it's not relevant

    sdata = sdata.drop('package_name', axis=1)

    # Convert text to lowercase
    sdata['review'] = sdata['review'].str.strip().str.lower()
    return sdata


# sdata = preprocess_data(sdata)


# Split into training and testing data
x = sdata['Headlines']
y = sdata['Sentiment']
# x = sdata['review']
# y = sdata['polarity']
x, x_test, y, y_test = train_test_split(x, y, stratify=y, test_size=0.25, random_state=42)


# Vectorize text reviews to numbers
vec = CountVectorizer(stop_words='english')
x = vec.fit_transform(x).toarray()
x_test = vec.transform(x_test).toarray()



smodel = MultinomialNB()
smodel.fit(x, y)

print(smodel.score(x_test, y_test))
print(smodel.predict(vec.transform(['not a good day for nepal'])))

filename = 'finalized_model.sav'
pickle.dump(smodel, open(filename, 'wb'))

pickle.dump(vec, open("vectorizer.pickle", "wb"))
